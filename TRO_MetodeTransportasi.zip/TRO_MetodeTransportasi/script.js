document.getElementById("hitungNWC").addEventListener("click", function() {
    const sumber = ["Cirebon", "Sukabumi", "Bekasi"];
    const tujuan = ["Tangerang", "Bogor", "Depok"];

    // Mengambil data input
    let biaya = {};
    sumber.forEach(s => {
        biaya[s] = {};
        tujuan.forEach(t => {
            const inputId = `${s.toLowerCase()}-${t.toLowerCase()}`;
            biaya[s][t] = parseInt(document.getElementById(inputId).value) || 0;
        });
    });

    let kapasitas = sumber.map(s => parseInt(document.getElementById(`kapasitas-${s.toLowerCase()}`).value) || 0);
    let permintaan = tujuan.map(t => parseInt(document.getElementById(`permintaan-${t.toLowerCase()}`).value) || 0);

    let hasil = Array(sumber.length).fill(0).map(() => Array(tujuan.length).fill(0));
    let totalBiaya = 0;
    let langkah = [];

    // Algoritma NWC
    let i = 0, j = 0;
    while (i < sumber.length && j < tujuan.length) {
        const alokasi = Math.min(kapasitas[i], permintaan[j]);
        hasil[i][j] = alokasi;
        kapasitas[i] -= alokasi;
        permintaan[j] -= alokasi;

        totalBiaya += alokasi * biaya[sumber[i]][tujuan[j]];
        langkah.push(`Alokasi ${alokasi} unit dari ${sumber[i]} ke ${tujuan[j]} dengan biaya ${alokasi} * ${biaya[sumber[i]][tujuan[j]]} = ${alokasi * biaya[sumber[i]][tujuan[j]]}`);

        if (kapasitas[i] === 0) i++;
        if (permintaan[j] === 0) j++;
    }

    // Menampilkan hasil ke tabel
    const hasilTableBody = document.querySelector("#hasilTable tbody");
    hasilTableBody.innerHTML = "";
    sumber.forEach((s, i) => {
        const row = document.createElement("tr");
        const sumberCell = document.createElement("td");
        sumberCell.textContent = s;
        row.appendChild(sumberCell);
        hasil[i].forEach(value => {
            const cell = document.createElement("td");
            cell.textContent = value;
            row.appendChild(cell);
        });
        const kapasitasCell = document.createElement("td");
        kapasitasCell.textContent = kapasitas[i];
        row.appendChild(kapasitasCell);
        hasilTableBody.appendChild(row);
    });

    // Menampilkan alur perhitungan
    const alurLangkah = document.getElementById("alurLangkah");
    alurLangkah.innerHTML = "";
    langkah.forEach(l => {
        const li = document.createElement("li");
        li.textContent = l;
        alurLangkah.appendChild(li);
    });

    // Menampilkan total biaya
    document.getElementById("totalBiaya").textContent = totalBiaya;
});
